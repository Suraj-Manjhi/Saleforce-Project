# Institute Management
<img width="960" alt="image" src="https://user-images.githubusercontent.com/106376953/213930720-bc9259cd-2d9d-4f78-b2a6-0a5252323caf.png">

## Features of the App
- Manages the different Courses offered by the Institue.
- Tracks the Student attendance and total count of the attendance in a month.
- Send automatic Email to the Student's Email ID if the Attenadance is less than the pre defined value.
- Displays List of Student enrolled in a Particular course.
- Separate Tab for marking the Attendance of each student in a course.
- A Scheduled Batch APEX which is used to update the Attendance count to 0 on 1st of every month.
- Appropriate Toast Messages and SLDS Modals.
